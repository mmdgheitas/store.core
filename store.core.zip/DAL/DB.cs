﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using be;

namespace DAL
{
    class DB:DbContext
    {
        
        public DbSet<human> humen { get; set; }
        public DbSet<Items> items { get; set; }
        public DbSet<Sold> solds { get; set; }
        //public DbSet<DATA> data { get; set; }
    }
}
