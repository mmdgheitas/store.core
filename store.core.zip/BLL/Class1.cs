﻿using System;

namespace BLL
{
    public class Class1
    {
    }
}
