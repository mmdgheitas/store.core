﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace be
{
    public class Sold
    {
        public int id { get; set; }
        public string code_mahsoul { get; set; }
        public string tedad { get; set; }
        public string name { get; set; }
        public string detail { get; set; }
        public string size { get; set; }
        public string user_name { get; set; }
        public string family { get; set; }
        public string user { get; set; }
        public string pass { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
        public string adress { get; set; }
        public string code_posti { get; set; }
        public string id_user { get; set; }
    }
}
