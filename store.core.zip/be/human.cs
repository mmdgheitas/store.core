﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace be
{
    public class human
    {
        public int id { get; set; }
        public string name { get; set; }
        public string family { get; set; }
        public string user { get; set; }
        public string pass { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
        public string adress { get; set; }
        public string code_posti { get; set; }
        public string id_user { get; set; }
        public List<Items> items { get; set; }
    }
}
