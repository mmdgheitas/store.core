﻿using System;

namespace be
{
    public class Class1
    {
    }
}
